<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
   
    <?php require_once "header.php"; ?>
    <?php  require_once "connectdb.php"; ?>
    <br>
    <br>
    <div class="container">
        <div class="row justify-content-md-center">
    
                <div class="col col-lg-5">
                <div class="login-content">
                                <form action="login.php" method="POST">
                                    <div class="section-title">
                                        <h3>Login</h3>
                                    </div>
                                    <div class="textbox-wrap">
                                    <div class="form-group">
                                            <label for="email">Email address</label>
                                            <input type="email" class="form-control" required="required" name="email" id="email" aria-describedby="emailHelp" placeholder="Enter email">
                                            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                                        </div>
                                        <div class="form-group">
                                            <label for="password">Password</label>
                                            <input type="password" class="form-control" required="required" name="password" id="password" placeholder="Password">
                                        </div>
                                    </div>
                                    <br>
                                    
                                    <button type="submit" name="login" class="btn btn-dark">Login</button>
                                    
                                </form> 
                </div>
            </div>
        <br>
           

                </div>
            </div>
                
        
    
    <br>
    <br>
   
    <?php include('footer.php') ?>
</body>
</html>
<?php

if(isset($_POST['login'])){
    
        $email = $_POST['email'];
        $pass = $_POST['password'];
        $sql = "select * from users where email = '$email' and password = '$pass'";
        $rs = mysqli_query($con,$sql);
      if(mysqli_num_rows($rs)>0)
      {
        $data=mysqli_fetch_array($rs);
        $roletype = $data['roletype'];
         if($roletype==1)
         {
            header("Refresh:0; url=index.php");
         }
         else
         {
            echo("invalid username password");
         }      
        
    
}
}
?>