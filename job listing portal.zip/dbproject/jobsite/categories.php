<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

    <title>Categories</title>
</head>
<body>
   
    <?php require_once "header.php"; ?>
    <?php  require_once "connectdb.php"; ?>
    <br>
    <?php 
    error_reporting(0);
      $id= $_GET['id'];
      $sql = "SELECT * from category where id = '$id'";
      $rs = mysqli_query($con,$sql);
      $catdata=mysqli_fetch_array($rs);
      
     // delete
     if($_GET['delid'])
     {
      $delid= $_GET['delid'];
      $sql1 = "delete from category where id = '$delid'";
      mysqli_query($con,$sql1);
      header('Location: categories.php');
     }
      
      ?>
    <div class="container">
        <div class="row">

            <div class="col-md-4">
                <div class="login-content">
                                <form action="categories.php" method="POST">
                                    <div class="section-title">
                                        <h3>Categories</h3>
                                    </div>
                                    <div class="textbox-wrap">
                                        <div class="input-group">
                                            <span class="input-group-addon "><i class="fa fa-user"></i></span>
                                            <input type="hidden" name="id" value="<?=$catdata['id']?>"> 
                                            <input type="text" name="Name"  value="<?=$catdata['name']?>" required="required" class="form-control" placeholder="Name">
                                            
                                        </div>
                                    </div>
                                    <br>
                                    
                                    <button type="submit" name="addcat" class="btn btn-dark">Add Category!</button>
                                    <button type="submit" name="updatecat" class="btn btn-dark">Update Category!</button>
                                </form> 
                </div>
            </div>
        <br>
            <div class="col-md-8">
          
        <div class="box">
        <table class="table table-hover">
  <thead>
    <tr>
      
      <th scope="col">ID</th>
      <th scope="col">Name</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
      <?php 
      $sql = "SELECT * from category";
      $rs = mysqli_query($con,$sql);
      while($data=mysqli_fetch_array($rs))
      {

      
      ?>
    <tr>
      
      <td><?= $data['id'] ?></td>
      <td><?= $data['name'] ?></td>
      <td>
          <a href="categories.php?id=<?= $data['id'] ?>" class="btn btn-dark">Edit</a>
          <a href="categories.php?delid=<?= $data['id'] ?>" class="btn btn-danger">Delete</a>
      </td>
    </tr>
    <?php 
        }
    ?>
  </tbody>
</table>
     </div>
     </div>
            



                </div>
            </div>
                
        
    
    <br>
    <?php include('footer.php') ?>
</body>
</html>
<?php


if(isset($_POST['addcat'])){
    if( empty($_POST['Name'])  )
    {
        echo "Please fillout all required field";
    }else{
        $catname = $_POST['Name'];
        $sql = "INSERT INTO category (name) VALUES ('$catname')";
        if( $con->query($sql) === TRUE){
           
                echo("<meta http-equiv='refresh' content='1'>");
                
        }
        else{
            echo "There was an error while adding new category";
        }
    }
}

//update
if(isset($_POST['updatecat'])){
    
        $catname = $_POST['Name'];
        $catid = $_POST['id'];
        $sql = "UPDATE `category` SET `name`='$catname' where `id` = '$catid' ";
        if( $con->query($sql) === TRUE){
            echo("<meta http-equiv='refresh' content='1'>");

        }
        else{
            echo "There was an error while updating category";
        }
    
}
?>