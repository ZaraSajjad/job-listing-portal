<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        .big-banner{
    background-image: url('banner.jpg');
    background-size: cover;
}
    </style>
    <title>Find My Job</title>
</head>
<body>
<?php include('header.php') ?>
<div class="jumbotron big-banner">
  <div class="container">
    <h1 class="display-4">Find My Job!</h1>
    <p class="lead">Findmyjob was founded in 2021 with a simple mission: <br>to help people find jobs. It’s now the largest job website<br> in the world, boasting 250 million monthly users with <br> 10 new job listings added every second. Biggest doesn’t<br> always mean best, but we chose Indeed as the best overall<br> job website due to its size, the number of industries, <br>lifestyles catered to, and its unmatched update frequency. </p>
  </div>
</div>
    <?php include('footer.php') ?>
</body>
</html>