<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>apply</title>
</head>
<body>
   
    <?php require_once "header.php"; ?>
    <?php  require_once "connectdb.php"; ?>
    <br>
    <br>
    <br>
    <br>
    <div class="container">
        <div class="row justify-content-md-center">
    
                <div class="col col-lg-5">
                <div class="login-content">
                                <form action="apply.php" method="POST">
                                    <div class="section-title">
                                        <h3>Apply</h3>
                                    </div>
                                    <div class="textbox-wrap">
                                    <div class="form-group">
                                            
                                            <label class="form-label" for="file">Kindly Uplaod your cv </label>
                                                <input type="file" class="form-control" id="file" name="file" />
                                        </div>
                                        
                                    </div>
                                    <br>
                                    
                                    <button type="submit" name="upload" class="btn btn-dark">uplaod</button>
                                    
                                </form> 
                </div>
            </div>
        <br>
           

                </div>
            </div>
                
        
    
    <br>
    <br>
    <br>
    <br>
    <?php include('footer.php') ?>
</body>
</html>
