<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Find My Job</title>
</head>
<body>
    <?php include('header.php') ?>
    <?php include('connectdb.php') ?>
    <br>
    <div class="container">
  <div class="row justify-content-md-center">
    
    <div class="col col-lg-5">
    <form action="jobs.php" method="post">
  
  <div class="form-group">
    <label for="Name">Job Name</label>
    <input type="text" name="name" id="name"  required="required" class="form-control" placeholder="Name">
  </div>

  <div class="form-group">
    <label for="description">Job Description </label>
    <textarea id="description" name="description" class="form-control" placeholder="Description" ></textarea>
  </div>
  
  <div class="form-group">
    <label for="skill">Job Skill</label>
    <input type="text" name="skill" id="skill"  required="required" class="form-control" placeholder="Skill">
  </div>

  <div class="form-group">
    <label for="timing">Job Timing</label>
    <input type="text" name="timing" id="timing"  required="required" class="form-control" placeholder="eg: 8 am to 5 pm">
  </div>

  <div class="form-group">
    <label for="date">Job Date</label>
    <input type="date" name="date" id="date"  required="required" class="form-control">
  </div>

  <div class="form-group">
    <label for="salary">Job Salary</label>
    <input type="text" name="salary" id="salary"  required="required" class="form-control" placeholder="Salary ( RS )">
  </div>

  <div class="form-group">
    <label for="location">Job Location</label>
    <textarea id="location" name="location" class="form-control" placeholder="Location" >
</textarea>
  </div>

  <div class="form-group">
    <label for="catid">Job Category</label>
    <select name="catid" id="catid">
    <?php 
      $sql = "SELECT * from category";
      $data = mysqli_query($con,$sql);
      if(mysqli_num_rows($data) > 0)
      {
        while($row=mysqli_fetch_array($data))
        {
          ?><option value="<?=$row['id'] ?>" > <?=$row['name'] ?> </option><?php
        }
      }
      else
      {
        ?><option>  Category not added </option><?php
      }
     
      
      ?>
    
    </select>
  </div>

  <button type="submit" name="addjob" id="addjob"  class="btn btn-dark">Submit</button>
</form>
    </div>
  </div>
 
</div>
<br>
    
    <?php

        if(isset($_POST['addjob'])){
           
                $name = $_POST['name'];
                $des = $_POST['description'];
                $skill = $_POST['skill'];
                $timing = $_POST['timing'];
                $date = date('d/m/y');
                $salary = $_POST['salary'];
                $location = $_POST['location'];
                $catid = $_POST['catid'];

               $sql = "INSERT INTO jobs( name,des,skill,timing, date, salary, location, catid) VALUES ('$name','$des','$skill','$timing','$date','$salary','$location','$catid')";
		
                  if(mysqli_query($con, $sql)){
                                
                                      echo("<meta http-equiv='refresh' content='1'>");
                                      
                              }
                              else{
                                  echo "There was an error while adding new job";
                              }
                        
        }
  ?>
  <?php include('footer.php') ?>
</body>
</html>