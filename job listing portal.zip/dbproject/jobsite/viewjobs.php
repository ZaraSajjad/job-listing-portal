<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Jobs</title>
</head>
<body>
    <?php include('header.php') ?>
    <?php include('connectdb.php') ?>
    <br>
    
    <div class="container">
  <!-- <div class="row justify-content-md-center"> -->
  <div class="row ">
  <?php 
      $sql = "SELECT * from jobs";
      $rs = mysqli_query($con,$sql);
      while($data=mysqli_fetch_array($rs))
      {
      ?>
      <br>
  <table class="table">
  <thead class="thead-dark">
    <tr>
      <th scope="col">Name</th>
      <th scope="col">Description</th>
      <th scope="col">Skill</th>
      <th scope="col">Timing</th>
      <th colspan="2" scope="col">Date</th>
      <th scope="col">Salary</th>
      <th scope="col">Location</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
  <br>
    <tr>
        
      <th scope="row "><?= $data['name'] ?></th>
      <td><?= $data['des'] ?></td>
      <td><?= $data['skill'] ?></td>
      <td><?= $data['timing'] ?></td>
      <td colspan="2"><?= $data['date'] ?></td>
      <td><?= $data['salary'] ?></td>
      <td><?= $data['location'] ?></td>
      <td>
          <a href="apply.php">
      <button type="submit" class="btn btn-dark">Apply</button>
      </a>
      </td>
    </tr>
    
    
  </tbody>
</table>

<?php 
   
        }
    ?>
</div> 

  
    </div>
    <?php include('footer.php') ?>
</body>
</html>