<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
</head>
<body>
   
    <?php require_once "header.php"; ?>
    <?php  require_once "connectdb.php"; ?>
    <br>
    
    <div class="container">
        <div class="row justify-content-md-center">
    
                <div class="col col-lg-5">
                <div class="login-content">
                                <form action="register.php" method="POST">
                                    <div class="section-title">
                                        <h3>Register</h3>
                                    </div>
                                    <div class="textbox-wrap">
                                    <div class="form-group">
                                            <label for="name">Name</label>
                                            <input type="text" class="form-control" required="required" name="name" id="name"  placeholder="Enter Name">
                                        </div>    
                                    <div class="form-group">
                                            <label for="email">Email address</label>
                                            <input type="email" class="form-control" required="required" name="email" id="email" aria-describedby="emailHelp" placeholder="Enter email">
                                            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                                        </div>
                                        <div class="form-group">
                                            <label for="password">Password</label>
                                            <input type="password" class="form-control" required="required" name="password" id="password" placeholder="Password">
                                        </div>
                                    </div>
                                    <br>
                                    
                                    <button type="submit" name="register" id="register" class="btn btn-dark">Register</button>
                                    
                                </form> 
                </div>
            </div>
        <br>
            <div class="col-md-8">

     </div>

                </div>
            </div>
                
        
    
    <br>
    <?php include('footer.php') ?>
</body>
</html>
<?php

if(isset($_POST['register'])){

        $name = $_POST['name'];
        $email = $_POST['email'];
        $pass = $_POST['password'];
        $sql = "INSERT INTO users(name,email,password,roletype) VALUES ('$name','$email','$pass',2)";
        
		
        if(mysqli_query($con, $sql)){
                      
                            echo("<meta http-equiv='refresh' content='1'>");
                            
                    }
                    else{
                        echo "There was an error while adding new job";
                    }
              
           
}
?>
